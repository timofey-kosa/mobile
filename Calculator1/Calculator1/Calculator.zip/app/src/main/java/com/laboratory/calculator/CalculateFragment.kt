package com.laboratory.calculator

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import kotlinx.android.synthetic.main.fragment_calculate.*

class CalculateFragment : Fragment() {
    private val RESULT_TAG = "resultFragment"

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_calculate, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sendResultButton.setOnClickListener {
            if (number1.text.isNullOrBlank() || number2.text.isNullOrBlank()) {
                Toast.makeText(context, "Введите числа в поля", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val first = number1.text.toString().toDouble()
            val second = number2.text.toString().toDouble()
            val sum = when {
                addButton.isChecked -> first + second
                subtractButton.isChecked -> first - second
                multiplyButton.isChecked -> first * second
                divideButton.isChecked -> first / second
                else -> 0.0
            }
            sendResult(sum)
        }
    }

    private fun sendResult(result: Double) {
        val fragment = ResultFragment(result)
        val transaction = activity!!.supportFragmentManager.beginTransaction()

        // Удаление фрагмента с результатом, если он существует
        val previousResult = activity!!.supportFragmentManager.findFragmentByTag(RESULT_TAG)
        if (previousResult != null)
            transaction.remove(previousResult)

        // Добавление фрагмента к activity_main
        transaction.add(R.id.mainActivity, fragment, RESULT_TAG)
        transaction.commit()
    }
}
